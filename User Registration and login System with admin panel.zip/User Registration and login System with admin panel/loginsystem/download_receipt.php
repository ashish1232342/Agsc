<?php
require('fpdf182/fpdf.php'); // FPDF library

if (!isset($_GET['payment_id'])) {
    die("Payment ID is required");
}

$paymentId = $_GET['payment_id'];

// Razorpay API credentials
$keyId = 'YOUR_KEY_ID';
$keySecret = 'YOUR_KEY_SECRET';

// Fetch payment details from Razorpay API
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.razorpay.com/v1/payments/$paymentId");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERPWD, $keyId . ':' . $keySecret);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    die('Error fetching payment details: ' . curl_error($ch));
}

curl_close($ch);

$paymentData = json_decode($response, true);

if (!$paymentData || isset($paymentData['error'])) {
    die('Invalid payment ID or unable to fetch payment details.');
}

// Extract relevant data
$customerName = $paymentData['notes']['customer_name'] ?? 'N/A';
$serviceName = $paymentData['notes']['service'] ?? 'N/A';
$amountPaid = $paymentData['amount'] / 100; // amount in INR (Razorpay stores amount in paise)
$paymentDate = date('d-m-Y H:i:s', $paymentData['created_at']);

class PDF extends FPDF {
    function Header(){
        $this->SetFont('Arial','B',15);
        $this->Cell(0,10,'Ashish Internet Cafe - Payment Receipt',0,1,'C');
        $this->Ln(5);
    }

    function Footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Thank you for your payment!',0,0,'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

$pdf->Cell(0,10,"Payment ID: $paymentId",0,1);
$pdf->Cell(0,10,"Date: $paymentDate",0,1);
$pdf->Cell(0,10,"Customer Name: $customerName",0,1);
$pdf->Cell(0,10,"Service: $serviceName",0,1);
$pdf->Cell(0,10,"Amount Paid: ₹$amountPaid",0,1);

$pdf->Output('D', 'Receipt_'.$paymentId.'.pdf');
