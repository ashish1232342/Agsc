<?php
// aboutus.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Ashish Internet Cafe</title>

  <!-- SEO Meta Tags -->
  <meta name="description" content="Learn more about Ashish Internet Cafe and meet our team." />
  <meta property="og:title" content="About Ashish Internet Cafe" />
  <meta property="og:description" content="Your trusted cyber cafe for internet, printing, CSC services and more." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="http://yourwebsite.com/aboutus.php" />
  <meta property="og:image" content="http://yourwebsite.com/images/og-image.jpg" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />

  <style>
    /* Reset & base */
    *, *::before, *::after {
      box-sizing: border-box;
    }
    body {
      margin: 0; padding: 0;
      font-family: 'Poppins', sans-serif;
      background: #0f2027;
      color: #eee;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    /* Navbar */
    header {
      position: fixed;
      top: 0; left: 0; right: 0;
      background: rgba(15,32,39,0.85);
      backdrop-filter: saturate(180%) blur(20px);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      z-index: 1000;
      transition: background-color 0.3s ease;
    }

    header.scrolled {
      background-color: #001011cc;
    }

    header h1 {
      font-weight: 700;
      font-size: 1.8rem;
      letter-spacing: 3px;
      color: #00d2ff;
      user-select: none;
      cursor: default;
    }

    nav {
      display: flex;
      gap: 2rem;
    }

    nav a {
      font-weight: 600;
      font-size: 1.1rem;
      color: #eee;
      position: relative;
      transition: color 0.3s ease;
    }

    nav a.active,
    nav a:hover {
      color: #00d2ff;
    }

    nav a.active::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      right: 0;
      height: 2px;
      background: #00d2ff;
      border-radius: 2px;
    }

    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
      gap: 5px;
    }

    .hamburger div {
      width: 25px;
      height: 3px;
      background: #00d2ff;
      border-radius: 2px;
    }

    @media (max-width: 768px) {
      nav {
        position: fixed;
        top: 65px;
        right: -100%;
        background: #001011ee;
        height: 100vh;
        width: 200px;
        flex-direction: column;
        gap: 1.5rem;
        padding: 1rem;
        transition: right 0.3s ease;
      }
      nav.active {
        right: 0;
      }
      .hamburger {
        display: flex;
      }
    }

    main {
      flex-grow: 1;
      padding: 6rem 2rem 3rem;
      max-width: 900px;
      margin: 0 auto;
    }

    h2 {
      font-size: 2.8rem;
      color: #00d2ff;
      margin-bottom: 1rem;
      min-height: 60px; /* for typing animation space */
    }

    /* Typing animation styles */
    .typing {
      border-right: 3px solid #00d2ff;
      white-space: nowrap;
      overflow: hidden;
      animation: typing 3.5s steps(40, end), blink-caret 0.75s step-end infinite;
      width: 100%;
      max-width: 100%;
    }

    @keyframes typing {
      from { width: 0 }
      to { width: 100% }
    }

    @keyframes blink-caret {
      50% { border-color: transparent }
      100% { border-color: #00d2ff }
    }

    p {
      font-size: 1.2rem;
      color: #ccc;
      margin-bottom: 3rem;
    }

    /* Team Section */
    .team {
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
      gap: 2rem;
    }

    .member-card {
      background: #132c33;
      border-radius: 10px;
      padding: 1.5rem;
      text-align: center;
      box-shadow: 0 2px 10px rgb(0 210 255 / 0.2);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      color: #eee;
      cursor: default;
      perspective: 800px;
    }

    .member-card:hover {
      transform: scale(1.05) rotateY(10deg);
      box-shadow: 0 8px 20px rgb(0 210 255 / 0.6);
    }

    .member-photo {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 1rem;
      border: 3px solid #00d2ff;
    }

    .member-name {
      font-weight: 700;
      font-size: 1.2rem;
      margin-bottom: 0.3rem;
      color: #00d2ff;
    }

    .member-role {
      font-size: 1rem;
      color: #aaa;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 2rem 1rem;
      color: #666;
      font-size: 0.9rem;
      background: #001011cc;
      user-select: none;
      margin-top: auto;
    }
  </style>
</head>
<body>

<header id="navbar">
  <h1>Ashish Internet Cafe</h1>
  <nav id="nav-menu">
    <a href="index.php">Home</a>
    <a href="aboutus.php" class="active">About</a>
    <a href="servicebook.php">Services</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="hamburger" id="hamburger">
    <div></div><div></div><div></div>
  </div>
</header>

<main>
  <h2 class="typing" id="typingHeading"></h2>
  <p>Welcome to Ashish Internet Cafe! We provide high-speed internet access, printing, CSC services, and assistance with various digital tasks.</p>

  <section class="team">
    <div class="member-card">
      <img src="https://randomuser.me/api/portraits/men/75.jpg" alt="Ramesh Kumar" class="member-photo" />
      <div class="member-name">Ramesh Kumar</div>
      <div class="member-role">Founder & Manager</div>
    </div>
    <div class="member-card">
      <img src="https://randomuser.me/api/portraits/women/65.jpg" alt="Anjali Sharma" class="member-photo" />
      <div class="member-name">Anjali Sharma</div>
      <div class="member-role">Customer Support</div>
    </div>
    <div class="member-card">
      <img src="https://randomuser.me/api/portraits/men/33.jpg" alt="Suresh Patel" class="member-photo" />
      <div class="member-name">Suresh Patel</div>
      <div class="member-role">Technical Expert</div>
    </div>
    <div class="member-card">
      <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Meena Singh" class="member-photo" />
      <div class="member-name">Meena Singh</div>
      <div class="member-role">Service Coordinator</div>
    </div>
  </section>
</main>

<footer>
  &copy; <?php echo date("Y"); ?> Ashish Internet Cafe. All rights reserved.
</footer>

<!-- GSAP -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>

<script>
  // Navbar scroll background
  window.addEventListener("scroll", () => {
    document.getElementById("navbar").classList.toggle("scrolled", window.scrollY > 50);
  });

  // Hamburger menu toggle
  const hamburger = document.getElementById("hamburger");
  const navMenu = document.getElementById("nav-menu");
  hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
  });

  // Typing animation for About heading
  const typingText = "About Ashish Internet Cafe";
  const typingHeading = document.getElementById("typingHeading");
  let index = 0;

  function type() {
    if (index < typingText.length) {
      typingHeading.textContent += typingText.charAt(index);
      index++;
      setTimeout(type, 100);
    }
  }
  type();
</script>

</body>
</html>
