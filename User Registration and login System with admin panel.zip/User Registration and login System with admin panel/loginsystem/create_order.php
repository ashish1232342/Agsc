<?php
require('razorpay-php-master/Razorpay.php'); // Include Razorpay PHP SDK

use Razorpay\Api\Api;

header('Content-Type: application/json');

$keyId = 'rzp_test_UXGnrpf2UQCuoY';
$keySecret = 'OkUyZtJD4ap4gWSr4kijSBDx';

$api = new Api($keyId, $keySecret);

// Get POST data
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$service = $_POST['service'] ?? '';

if (!$name || !$email || !$service) {
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Define amounts in paise
$amounts = [
    'internet_access' => 5000,    // ₹50.00
    'printing' => 3000,           // ₹30.00
    'csc_services' => 10000,      // ₹100.00
    'digital_assistance' => 15000 // ₹150.00
];

$amount = $amounts[$service] ?? 5000; // default ₹50 if unknown

try {
    $orderData = [
        'receipt' => 'rcpt_' . time(),
        'amount' => $amount,
        'currency' => 'INR',
        'payment_capture' => 1, // Auto capture
        'notes' => [
            'customer_name' => $name,
            'service' => $service,
            'email' => $email
        ]
    ];

    $razorpayOrder = $api->order->create($orderData);

    echo json_encode([
        'orderId' => $razorpayOrder['id'],
        'amount' => $amount,
        'currency' => 'INR',
        'key' => $keyId,
        'name' => 'Ashish Internet Cafe',
        'description' => 'Service Booking Payment',
        'prefill' => [
            'name' => $name,
            'email' => $email
        ]
    ]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
<?php
require('razorpay-php-master/Razorpay.php');
use Razorpay\Api\Api;

header('Content-Type: application/json');

$keyId = 'YOUR_KEY_ID';        // Replace with your Razorpay Key ID
$keySecret = 'YOUR_KEY_SECRET';// Replace with your Razorpay Secret

$api = new Api($keyId, $keySecret);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$service = $_POST['service'] ?? '';
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
$date = $_POST['date'] ?? '';
$message = $_POST['message'] ?? '';

if (!$name || !$email || !$service || !$date) {
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Calculate amount in paise
switch ($service) {
    case 'internet_access':
        $amount = 5000; // ₹50
        $serviceName = "Internet Access";
        break;
    case 'printing':
        $amount = 300 * $quantity; // ₹3 per print
        $serviceName = "Printing ($quantity prints)";
        break;
    case 'csc_services':
        $amount = 10000; // ₹100
        $serviceName = "CSC Services";
        break;
    case 'digital_assistance':
        $amount = 15000; // ₹150
        $serviceName = "Digital Assistance";
        break;
    default:
        echo json_encode(['error' => 'Invalid service selected']);
        exit;
}

try {
    // Create Razorpay order
    $orderData = [
        'receipt'         => 'rcpt_'.time(),
        'amount'          => $amount,
        'currency'        => 'INR',
        'payment_capture' => 1 // auto capture
    ];

    $razorpayOrder = $api->order->create($orderData);

    // Send notification email to you
    $to = "pradeepmahto9696@gmail.com";
    $subject = "New Booking Received - $serviceName";
    $emailMessage = "New booking details:\n\n";
    $emailMessage .= "Name: $name\n";
    $emailMessage .= "Email: $email\n";
    $emailMessage .= "Service: $serviceName\n";
    if($service === 'printing'){
        $emailMessage .= "Quantity: $quantity prints\n";
    }
    $emailMessage .= "Preferred Date: $date\n";
    $emailMessage .= "Additional Message: $message\n";
    $emailMessage .= "Amount to be paid: ₹" . number_format($amount/100, 2) . "\n";
    $emailMessage .= "Order ID: " . $razorpayOrder['id'] . "\n";

    // Set headers
    $headers = "From: pradeepmahto9696@gmail.com\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Send mail
    mail($to, $subject, $emailMessage, $headers);

    // Respond with Razorpay order info
    echo json_encode([
        'key' => $keyId,
        'amount' => $amount,
        'name' => $name,
        'description' => $serviceName,
        'orderId' => $razorpayOrder['id'],
        'prefill' => [
            'name' => $name,
            'email' => $email
        ]
    ]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}
