<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Service Booking - Ashish Internet Cafe</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <style>
    body {
      background: #0f2027;
      color: #eee;
      font-family: 'Poppins', sans-serif;
      margin: 0; padding: 0;
    }
    header {
      background: #001011cc;
      padding: 1rem 2rem;
      position: fixed;
      top: 0; width: 100%;
      color: #00d2ff;
      font-weight: 700;
      font-size: 1.8rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 1000;
    }
    main {
      max-width: 600px;
      margin: 6rem auto 3rem;
      padding: 0 1rem;
    }
    form {
      background: #132c33;
      padding: 2rem;
      border-radius: 10px;
    }
    label {
      display: block;
      margin-top: 1rem;
      font-weight: 600;
    }
    input, select, textarea, button {
      width: 100%;
      padding: 0.5rem;
      margin-top: 0.3rem;
      border-radius: 5px;
      border: none;
      font-size: 1rem;
    }
    button {
      background: #00d2ff;
      color: #0f2027;
      margin-top: 1.5rem;
      font-weight: 700;
      cursor: pointer;
      border-radius: 25px;
      transition: background 0.3s ease;
    }
    button:hover {
      background: #007ea7;
    }
  </style>
    <style>
    /* Reset & base */
    *, *::before, *::after {
      box-sizing: border-box;
    }
    body {
      margin: 0; padding: 0;
      font-family: 'Poppins', sans-serif;
      background: #0f2027;
      color: #eee;
      line-height: 1.6;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    /* Navbar */
    header {
      position: fixed;
      top: 0; left: 0; right: 0;
      background: rgba(15,32,39,0.85);
      backdrop-filter: saturate(180%) blur(20px);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      z-index: 1000;
      transition: background-color 0.3s ease;
    }

    header.scrolled {
      background-color: #001011cc;
    }

    header h1 {
      font-weight: 700;
      font-size: 1.8rem;
      letter-spacing: 3px;
      color: #00d2ff;
      user-select: none;
      cursor: default;
    }

    nav {
      display: flex;
      gap: 2rem;
    }

    nav a {
      font-weight: 600;
      font-size: 1.1rem;
      color: #eee;
      position: relative;
      transition: color 0.3s ease;
    }

    nav a.active,
    nav a:hover {
      color: #00d2ff;
    }

    nav a.active::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      right: 0;
      height: 2px;
      background: #00d2ff;
      border-radius: 2px;
    }

    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
      gap: 5px;
    }

    .hamburger div {
      width: 25px;
      height: 3px;
      background: #00d2ff;
      border-radius: 2px;
    }

    @media (max-width: 768px) {
      nav {
        position: fixed;
        top: 65px;
        right: -100%;
        background: #001011ee;
        height: 100vh;
        width: 200px;
        flex-direction: column;
        gap: 1.5rem;
        padding: 1rem;
        transition: right 0.3s ease;
      }
      nav.active {
        right: 0;
      }
      .hamburger {
        display: flex;
      }
    }

    /* Hero Section */
    .hero {
      padding: 8rem 2rem 4rem;
      text-align: center;
      max-width: 700px;
      margin: 0 auto;
    }

    .hero h2 {
      font-size: 2.8rem;
      color: #00d2ff;
      opacity: 0;
      transform: translateY(30px);
    }

    .hero p {
      font-size: 1.2rem;
      color: #ccc;
      margin: 1rem 0 2rem;
      opacity: 0;
      transform: translateY(30px);
    }

    .btn-primary {
      padding: 0.8rem 2rem;
      background: #00d2ff;
      border: none;
      border-radius: 25px;
      color: #0f2027;
      font-weight: 700;
      cursor: pointer;
      font-size: 1.1rem;
      opacity: 0;
      transform: translateY(30px);
      display: inline-block;
    }

    .btn-primary:hover {
      background: #007ea7;
    }

    /* Services */
    .services {
      max-width: 1100px;
      margin: 0 auto;
      padding: 4rem 2rem;
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
      gap: 2rem;
    }

    .service-card {
      background: #132c33;
      padding: 1.5rem;
      border-radius: 10px;
      text-align: center;
      opacity: 0;
      transform: translateY(40px);
      color: #eee;
      box-shadow: 0 2px 10px rgb(0 210 255 / 0.2);
      transition: transform 0.3s ease;
    }

    .service-card:hover {
      transform: translateY(0) scale(1.05);
      box-shadow: 0 8px 20px rgb(0 210 255 / 0.6);
    }

    .service-card h3 {
      color: #00d2ff;
      margin-bottom: 1rem;
    }

    /* Testimonials */
    .testimonials {
      max-width: 900px;
      margin: 4rem auto;
      padding: 0 2rem;
      text-align: center;
      color: #ccc;
    }

    .testimonials h2 {
      margin-bottom: 2rem;
      color: #00d2ff;
    }

    .testimonial-slide {
      font-style: italic;
      font-size: 1.2rem;
      min-height: 80px;
      margin-bottom: 1rem;
      opacity: 0;
    }

    .testimonial-author {
      font-weight: 600;
      color: #00d2ff;
    }

    /* Newsletter */
    .newsletter {
      background: #001011cc;
      max-width: 700px;
      margin: 4rem auto 6rem;
      padding: 2rem;
      border-radius: 10px;
      text-align: center;
    }

    .newsletter h2 {
      margin-bottom: 1rem;
      color: #00d2ff;
    }

    .newsletter input[type=email] {
      padding: 0.8rem;
      width: 70%;
      border: none;
      border-radius: 25px 0 0 25px;
      outline: none;
      font-size: 1rem;
    }

    .newsletter button {
      padding: 0.8rem 1.5rem;
      border: none;
      background: #00d2ff;
      color: #0f2027;
      font-weight: 700;
      border-radius: 0 25px 25px 0;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    .newsletter button:hover {
      background: #007ea7;
    }

    /* Back to top button */
    #backToTop {
      position: fixed;
      bottom: 40px;
      right: 40px;
      background: #00d2ff;
      color: #0f2027;
      border: none;
      padding: 0.8rem 1.2rem;
      border-radius: 50px;
      cursor: pointer;
      font-weight: 700;
      display: none;
      z-index: 1001;
      box-shadow: 0 3px 8px rgba(0,210,255,0.7);
    }

    #backToTop:hover {
      background: #007ea7;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 2rem 1rem;
      color: #666;
      font-size: 0.9rem;
      background: #001011cc;
      user-select: none;
    }
  </style>
</head>
<body>

<header id="navbar">
  <h1>Ashish Internet Cafe</h1>
  <nav id="nav-menu">
    <a href="index.php" class="active">Home</a>
    <a href="about.php">About</a>
    <a href="servicebook.php">Book Services</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="hamburger" id="hamburger">
    <div></div><div></div><div></div>
  </div>
</header>

<main>
  <h2>Book a Service</h2>
  <form id="bookingForm">
    <label for="name">Full Name*</label>
    <input type="text" id="name" name="name" placeholder="Your full name" required />

    <label for="email">Email Address*</label>
    <input type="email" id="email" name="email" placeholder="you@example.com" required />

<label for="service">Select Service*</label>
<select id="service" name="service" required>
  <option value="" disabled selected>Select a service</option>
  <option value="internet_access">Internet Access - ₹50</option>
  <option value="printing">Printing - ₹3 per print</option>  <!-- note price -->
  <option value="csc_services">CSC Services - ₹100</option>
  <option value="digital_assistance">Digital Assistance - ₹150</option>
</select>

<label for="quantity" id="quantityLabel" style="display:none;">Number of Prints*</label>
<input type="number" id="quantity" name="quantity" min="1" value="1" style="display:none;" />


    <label for="date">Preferred Date*</label>
    <input type="date" id="date" name="date" required />

    <label for="message">Additional Details</label>
    <textarea id="message" name="message" rows="4" placeholder="Tell us more..."></textarea>

    <button type="submit">Pay & Book Now</button>
  </form>
</main>

<script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<!-- Your payment & verification script -->
<script>
document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const formData = new FormData(this);

  fetch('create_order.php', { // Your PHP order creation endpoint
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if(data.error){
      alert("Error: " + data.error);
      return;
    }

    const options = {
      "key": data.key,
      "amount": data.amount,
      "currency": "INR",
      "name": data.name,
      "description": data.description,
      "order_id": data.orderId,
      "prefill": {
        "name": data.prefill.name,
        "email": data.prefill.email,
      },
      "handler": function (response){
        // Payment succeeded
        verifyPayment(response, data.orderId);
      },
      "theme": {
        "color": "#00d2ff"
      }
    };

    const rzp = new Razorpay(options);
    rzp.open();
  })
  .catch(err => {
    alert("Failed to initiate payment: " + err);
  });
});

function verifyPayment(paymentResponse, orderId){
  fetch('verify_payment.php', { // New script to verify payment signature
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      razorpay_payment_id: paymentResponse.razorpay_payment_id,
      razorpay_order_id: paymentResponse.razorpay_order_id,
      razorpay_signature: paymentResponse.razorpay_signature
    })
  })
  .then(res => res.json())
  .then(data => {
    if(data.status === 'success'){
      alert("Payment successful!");
      // Redirect or download receipt
      window.location.href = 'download_receipt.php?payment_id=' + paymentResponse.razorpay_payment_id;
    } else {
      alert("Payment verification failed: " + data.message);
    }
  })
  .catch(err => {
    alert("Verification error: " + err);
  });
}
document.getElementById('service').addEventListener('change', function() {
  const quantityInput = document.getElementById('quantity');
  const quantityLabel = document.getElementById('quantityLabel');
  if (this.value === 'printing') {
    quantityInput.style.display = 'block';
    quantityLabel.style.display = 'block';
    quantityInput.setAttribute('required', 'required');
  } else {
    quantityInput.style.display = 'none';
    quantityLabel.style.display = 'none';
    quantityInput.removeAttribute('required');
  }
});

</script>
</script>

</body>
</html>
