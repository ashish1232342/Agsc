<?php
header('Content-Type: application/json');

require('razorpay-php-master/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$keyId = 'rzp_test_UXGnrpf2UQCuoY';
$keySecret = 'OkUyZtJD4ap4gWSr4kijSBDx';

$api = new Api($keyId, $keySecret);

$input = json_decode(file_get_contents('php://input'), true);

$attributes = [
  'razorpay_order_id' => $input['razorpay_order_id'],
  'razorpay_payment_id' => $input['razorpay_payment_id'],
  'razorpay_signature' => $input['razorpay_signature']
];

try {
    $api->utility->verifyPaymentSignature($attributes);
    echo json_encode(['status' => 'success']);
} catch(SignatureVerificationError $e) {
    echo json_encode(['status' => 'fail', 'message' => $e->getMessage()]);
}
